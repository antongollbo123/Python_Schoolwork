import string


def find_emailadress(text, at_index):
    EMAIL_CHARS = string.ascii_letters+string.digits+"."+"_"
    first_index = 0
    for index in range(at_index-1, -1, -1):
        if text[index] not in EMAIL_CHARS:
            first_index = index + 1
            break
    return first_index

#hitta slutindex
def find_emailadress2(text, at_index):
    EMAIL_CHARS = string.ascii_letters+string.digits+"."+"_"
    end_index = len(text)
    for index in range(at_index+1, len(text),1):
        if text[index] not in EMAIL_CHARS:
            end_index = index-1 
            break
    return end_index

def find_first_email(text):
    EMAIL_CHARS = string.ascii_letters+string.digits+"."+"_"
    at_index = text.find('@')
    
    if at_index < 0:
         return None,None
    elif at_index == len(text)-1:
         return None, ""
    elif at_index == 0:
        return None, text[1:]
    elif text[at_index+1] not in EMAIL_CHARS or text[at_index-1] not in EMAIL_CHARS:
        return None, text[at_index+1:]
    else:
        name_start = find_emailadress(text, at_index)
        name_end = find_emailadress2(text,at_index)

        if text[name_end-1]==".":
            email_adress = text[name_start:name_end-1]
            rest_of_text = text[name_end:]
            return email_adress, rest_of_text
        else:
            email_adress = text[name_start : name_end+1]
            rest_of_text = text[name_end+1:]
        return email_adress, rest_of_text
       

##def test():
##    testcases = ["jag ,. heter., antongollbo@gmail.com jig",
##                 "dar satt den, ErikLundman@gmail.com", "MarcusLotman@gmail.com heter jag vad heter du",
##                 "@tjabba@", "Eriklundman@@hotmail.com", "@hi joachim@hotmail.com"]
##    for i in testcases:
##        print find_first_email(i)
##test()

from Lab4Upp1 import *
from Lab4Upp2 import *
from Lab4Upp3 import *
from Lab4Upp41 import *
from Lab4Upp5 import *
from Lab4Upp6 import *

def test1():
    testcases = ["jag ,. heter., antongollbo@gmail.com jig",
                "dar satt den, ErikLundman@gmail.com",
                "MarcusLotman@gmail.com heter jag vad heter du",
                "@tjabba@", "Eriklundman@@hotmail.com", "@hi joachim@hotmail.com",
                 "@tjabba, @tjabba", "a@a", ""]
    for i in testcases:
        print find_first_email(i)

def test2():
    testcases = ["Hej Antongollbo@gmail.com eriklundman@gmail.com hejda",
                 "antongollbo@gmail.com, marcuslothman@hotmail.com", "I dont like you"
                 "I dont@ like you, eriklundman@hotmail.com jg ",]
    for i in testcases:
        print emails_to_list(i)
        
def test3():
    testcases  = ["http://www.it.uu.se/katalog/bylastname",
                  "http://user.it.uu.se/~joachim/"]
    for i in testcases:
        print find_emails(i)

def test4():
    testcases = ["http://user.it.uu.se/~joachim/"]
    for i in testcases:
        print all_websites(i)

def test5():
    testcases = ["http://user.it.uu.se/~joachim/","http://fyrisbiografen.com"]
    for i in testcases:
        print get_full_url(i)

def test6():
    testcases = ["http://user.it.uu.se/~joachim/", "http://fyrisbiografen.com"]
    for i in testcases:
        print find_dead_links(i)
    

import urllib

def find_website(url):
    
    file_obj = urllib.urlopen(url)
    website_text = file_obj.read()
    
    lower_website_text = website_text.lower()
    replace_website_text = lower_website_text.replace(" ", "")
    final_website_text = replace_website_text.replace('"', "")
    return final_website_text
def url_start_end(url):
    web_text = find_website(url)
    url_list = []
    url_start = web_text.find('<ahref=',0)
    url_end = web_text.find('>',url_start+7)
    
    url_list.append(web_text[url_start+7 : url_end])
    url_2nd_end = url_end
    
    while web_text.find('<ahref=') != -1:
        
        url_start = url_2nd_end
        url_new_start = web_text.find('<ahref=', url_start)
        url_2nd_end = web_text.find('>', url_new_start+7)
        url_list.append(find_website(url)[url_new_start+7 : url_2nd_end])
        

        if url_2nd_end == -1 or url_new_start == -1 or url_start == -1:
            break
    return url_list[0:-1]

def all_websites(url):
    a = url_start_end(url)
    b = set(a)
    for elem in b:
        print elem
    return elem 

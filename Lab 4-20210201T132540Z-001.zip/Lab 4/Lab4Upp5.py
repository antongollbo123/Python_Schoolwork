from Lab4Upp41 import *
from urlparse import urljoin


def get_full_url(url):
    url_list1 = []
    url_list2 = url_start_end(url)
    
    for elem in url_list2:
        
        url_list1.append(urljoin(url, elem)) 

    return url_list1

from Lab4Upp5 import *
import socket
socket.setdefaulttimeout(3)
import urllib

def find_dead_links(url):
    url_list1 = get_full_url(url)
    
    for elem in url_list1:

        if elem.find("http://") != -1:
        
            try:
                urllib.urlopen(elem)
                print elem, "Funkar att oppna"
            except:
                print elem, "Funkar ej"
        else:
            pass

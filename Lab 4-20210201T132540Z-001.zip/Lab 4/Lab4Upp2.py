from Lab4Upp1 import *
import string

def emails_to_list(text):
    list_of_emails = []
    at_index=text.find("@")
    while at_index != -1:
        adress_and_text = find_first_email(text)
        if adress_and_text[0] == None and adress_and_text[1].find("@") == -1 :
                return list_of_emails
        else:
            if adress_and_text[0] == None:
                text=adress_and_text[1]
                at_index=text.find("@")
            else:   
                list_of_emails.append(adress_and_text[0])
                text=adress_and_text[1]
                at_index=text.find("@")
    return list_of_emails


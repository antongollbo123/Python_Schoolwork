import urllib
import string
from Lab4Upp2 import *

def find_emails(url):
    file_obj = urllib.urlopen(url)
    website_text = file_obj.read()
    list_of_emails = emails_to_list(website_text)
    unique_list = set(list_of_emails)
    for elem in unique_list:
        print elem
    return

##def test():
##    testcases  = ["http://www.it.uu.se/katalog/bylastname",
##                  "http://user.it.uu.se/~joachim/"]
##    for i in testcases:
##        print find_emails(i)

import urllib
def find_website(url):
    
    file_obj = urllib.urlopen(url)
    website_text = file_obj.read()
    
    lower_website_text = website_text.lower()
    final_website_text = lower_website_text.replace(" ", "")
    
    url_start = final_website_text.find('<ahref="',0)
    url_end = final_website_text.find('"',url_start+8)
    full_url = final_website_text[url_start+8 : url_end]
    
    return final_website_text, full_url

def find_several_websites(url):
    list_of_websites = []
    a = find_website(url)
    link_index = a[0].find('<ahref="')
    
    while link_index != -1:
        list_of_websites.append(find_website(url)[1])
        
        next_link_index = a[0].find('<ahref="', link_index)
        link_index = a[0].find('ahref="', next_link_index)

    return list_of_websites




##def find_all_websites(url):
##    find_several_websites(url)
##    
##    a = emails_to_list(website_text)
##    b = set(a)
##    for elem in b:
##        print elem
##

        
        
    
    

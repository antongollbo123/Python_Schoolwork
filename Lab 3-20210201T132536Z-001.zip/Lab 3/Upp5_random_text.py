from Upp5_random_text_def import *
import random 


def random_text(textfil, antalord):
    
    word_list = import_file_to_list(textfil)
    dictionary = create_dictionary(word_list)
    lista = []
    random_ord = random.choice(dictionary.keys())
    
    while antalord >= len(lista):
        if random_ord not in dictionary.keys():
            random_ord = random.choice(dictionary.keys())
        
        lista.append(random_ord)
        random_values = dictionary[random_ord]
        random_ord = random.choice(random_values)
    return " ".join(lista)


                
        



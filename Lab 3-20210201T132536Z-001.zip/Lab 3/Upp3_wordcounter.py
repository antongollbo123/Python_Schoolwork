from import_file import *

def word_counter(textfil):
    imported_text = import_file_to_list(textfil)
    stripped_text = remove_signs(imported_text)
    word_count = len(stripped_text)
    print "Antal ord �r: ", word_count

    dictionary = make_dictionary(stripped_text)
    unique_words = len(dictionary)
    print "Antal unika ord �r: ", unique_words

    countmax = count_max(dictionary)
    print "Vanligaste ordet:",[countmax[1]], "och det f�rekommer: ", countmax[0], "ggr ;)"


def test():
    testcases = ["longtext.txt"]
    for i in testcases:
        print word_counter(i)
test()

        
        


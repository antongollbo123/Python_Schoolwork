import os
os.chdir("C:/Python27/Program/Labbar/Lab 3")

def import_file_to_list(fil):
    text_file = open(fil,"r")
    raw_text = text_file.read()
    
    raw_text = raw_text.lower()
    word_list = raw_text.split()
    return word_list

def remove_signs(word_list):
    word_list_stripped = []
    for word in word_list:
        word_stripped = word.strip('!?,.-;:_@#%&/()=+${[]}\^"<>|*1234567890')
        word_list_stripped += [word_stripped]
    return word_list_stripped

def make_dictionary(alist):
    dictionary = {}
    for words in alist:
        dictionary[words] = dictionary.get(words, 0) + 1
    return dictionary

def count_max(dictionary):
    common_word = ""
    antal_forekomster = 0
    for orden in dictionary:
        if dictionary[orden] > antal_forekomster:
            antal_forekomster = dictionary[orden]
            common_word = orden
    return antal_forekomster , common_word
    

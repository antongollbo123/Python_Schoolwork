import os
os.chdir("C:/Python27/Program/Labbar/Lab 3")
from collections import defaultdict

def create_dictionary(alist):
    dictionary = defaultdict(list)
    
    for word in range(len(alist)-1):
        dictionary[alist[word]].append(alist[word+1])  
    return dictionary

def import_file_to_list(fil):
    text_file = open(fil,"r")
    raw_text = text_file.read()
    word_list = raw_text.split()
    return word_list

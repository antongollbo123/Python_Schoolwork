from Upp4_dictionary_consecutive_words import *

def count_consecutive_words(textfil):
    imported_text = import_file_to_list(textfil)
    stripped_text = remove_signs(imported_text)

    common_word = counter(stripped_text)
    return "vanligaste ordet", common_word[0], "vanligaste efterfoljande:", common_word[1]
    

def test():
    testcases = ["bible.txt", "HP.txt", "longtext.txt"]
    for i in testcases:
        print count_consecutive_words(i)
test()
    

import os
os.chdir("C:\Python27\Program\Labbar\Lab 3")
from collections import defaultdict

def import_file_to_list(fil):
    text_file = open(fil,"r")
    raw_text = text_file.read()
    
    raw_text = raw_text.lower()
    word_list = raw_text.split()
    return word_list

def remove_signs(word_list):
    word_list_stripped = []
    for word in word_list:
        word_stripped = word.strip('!?,.-;:_@#%&/()=+${[]}\^"<>|*1234567890')
        word_list_stripped += [word_stripped]
    return word_list_stripped

def counter(alist):
    count_dictionary = {}
    for words in alist:
        count_dictionary[words] = count_dictionary.get(words, 0) + 1
    common_word = max(count_dictionary, key=count_dictionary.get)

    dictionary = defaultdict(list)  
    for word in range(len(alist)-1):
        #dictionary[alist[word]] = dictionary.get(alist[word], []) + [alist[word+1]]
        dictionary[alist[word]].append(alist[word+1])
    word_after_common = dictionary[common_word]

    word_after_dic = {}
    for words in word_after_common:
        word_after_dic[words] = word_after_dic.get(words, 0) + 1
    common_word_after = max(word_after_dic, key=word_after_dic.get)
    return common_word, common_word_after
